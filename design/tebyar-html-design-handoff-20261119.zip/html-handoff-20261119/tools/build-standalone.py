#!/usr/bin/env python3
"""Inline CSS, JS, fonts and images into tebyar-prototype.standalone.html for file:// use."""
from __future__ import annotations

import base64
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "tebyar-prototype.html"
OUT = ROOT / "tebyar-prototype.standalone.html"

MIME = {
    ".woff2": "font/woff2",
    ".woff": "font/woff",
    ".ttf": "font/ttf",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".svg": "image/svg+xml",
    ".webp": "image/webp",
}


def data_uri(path: Path) -> str:
    mime = MIME.get(path.suffix.lower(), "application/octet-stream")
    b64 = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{b64}"


def replace_asset_paths(text: str) -> str:
    def repl(m: re.Match) -> str:
        rel = m.group(0)
        rel = rel.replace("../assets/", "assets/")
        path = ROOT / rel
        if not path.exists():
            raise SystemExit(f"Missing asset referenced in source: {rel}")
        return data_uri(path)

    return re.sub(r"(?:\.\./)?assets/(?:fonts|images)/[A-Za-z0-9_./-]+", repl, text)


def main() -> None:
    html = SRC.read_text(encoding="utf-8")
    css = replace_asset_paths((ROOT / "css/tebyar.css").read_text(encoding="utf-8"))
    js = replace_asset_paths((ROOT / "js/tebyar.js").read_text(encoding="utf-8"))

    html, n_css = re.subn(
        r'<link\s+rel="stylesheet"\s+href="css/tebyar\.css[^"]*"\s*/?>',
        "<style>\n" + css + "\n</style>",
        html,
        count=1,
    )
    html, n_js = re.subn(
        r'<script\s+src="js/tebyar\.js[^"]*"\s*>\s*</script>',
        "<script>\n" + js + "\n</script>",
        html,
        count=1,
    )
    if n_css != 1 or n_js != 1:
        raise SystemExit(f"Expected to inline 1 CSS and 1 JS tag, got css={n_css} js={n_js}")

    html = replace_asset_paths(html)
    leftover = re.findall(r"(?:href|src)=[\"'](?:css/|js/|assets/)[^\"']+", html)
    leftover += re.findall(r"url\(\s*[\"']?(?:\.\./)?(?:assets/|css/)", html)
    if leftover:
        raise SystemExit(f"Leftover relative assets in standalone: {leftover}")

    OUT.write_text(html, encoding="utf-8")
    print(f"Wrote {OUT} ({OUT.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
