#!/usr/bin/env python3
"""Local headless Chrome QA for the TEBYAR design prototype. No remote browser."""
import json, os, re, subprocess, time, urllib.request
from pathlib import Path
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from threading import Thread

ROOT = Path("/workspace/tebyar/html-handoff-20261119").resolve()
QA = ROOT / "qa"
QA.mkdir(exist_ok=True)
CHROME = "google-chrome"
PORT = 8765
BASE = f"http://127.0.0.1:{PORT}/tebyar-prototype.html"

ROUTES = {
    "login": ["ورود پزشکان", "۰۹۱۲۰۰۰۱۱۲۲"],
    "otp": ["۲۴۸۳", "کد نمایشی"],
    "verify": ["احراز هویت", "شماره نظام نمونه‌ای"],
    "home": ["دکتر سارا کریمی", "بعد از درمانگاه", "استوری شما", "طبیار"],
    "compose": ["انتشار پست", "متن پست"],
    "post": ["نظرها", "بعد از درمانگاه"],
    "communities": ["انجمن قلب و عروق", "انجمن پوست"],
    "community": ["انجمن قلب و عروق", "کیس ناشناس"],
    "compose-case": ["چک‌لیست محرمانگی", "شناسه‌های بیمار"],
    "compose-poll": ["اجماع بالینی", "نشست علمی"],
    "messages": ["دکتر سارا کریمی", "پیام‌ها"],
    "chat": ["برنامه نشست", "پیام نمایشی"],
    "profile": ["دکتر سارا کریمی", "هویت تأییدشده", "دنبال‌کننده"],
    "profile-edit": ["ویرایش پروفایل", "بیوگرافی"],
    "search": ["جست‌وجوی پزشکان", "دکتر محمد رضایی"],
    "jobs": ["فاز ۲", "فرصت"],
    "job": ["بیمارستان نمونه تهران", "فاز ۲"],
    "apply": ["رزومه", "ارسال نمی‌شود"],
    "notifications": ["اعلان", "دیدگاه"],
    "settings": ["حریم خصوصی", "tebyar-theme"],
    "index": ["فهرست صفحات", "ورود و ثبت‌نام"],
}

def chrome(args, timeout=30):
    cmd = [
        CHROME, "--headless=new", "--no-sandbox", "--disable-gpu",
        "--disable-dev-shm-usage", "--hide-scrollbars",
        "--user-data-dir=/tmp/tebyar-chrome-qa",
        "--virtual-time-budget=6000",
    ] + args
    return subprocess.run(cmd, capture_output=True, timeout=timeout)

def dump(url):
    r = chrome([f"--dump-dom={url}"]) if False else chrome([f"--dump-dom", url])
    return r

def screenshot(url, dest, w=390, h=844):
    dest = Path(dest)
    r = chrome([f"--window-size={w},{h}", f"--screenshot={dest}", url])
    return r.returncode == 0 and dest.exists() and dest.stat().st_size > 1000

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **k):
        super().__init__(*a, directory=str(ROOT), **k)
    def log_message(self, *a):
        pass

def main():
    httpd = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    t = Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    time.sleep(0.3)
    results = []
    # health
    urllib.request.urlopen(BASE, timeout=3)

    # Route tests (light)
    for route, needles in ROUTES.items():
        url = f"{BASE}#/{route}"
        r = chrome(["--dump-dom", url], timeout=40)
        dom = r.stdout.decode("utf-8", "replace")
        ok_active = f'data-route="{route}"' in dom and "is-active" in dom
        # tighter: the active section
        m = re.search(rf'<section[^>]*data-route="{route}"[^>]*>', dom)
        section_ok = bool(m and "is-active" in m.group(0))
        missing = [n for n in needles if n not in dom]
        rtl = 'dir="rtl"' in dom
        entry = {
            "route": route,
            "active": section_ok,
            "rtl": rtl,
            "missing_text": missing,
            "chrome_stderr_tail": r.stderr.decode("utf-8", "replace")[-400:],
            "ok": section_ok and rtl and not missing and r.returncode == 0,
        }
        results.append(entry)
        print(("OK " if entry["ok"] else "FAIL"), route, "active="+str(section_ok), "missing="+str(missing))

    shots = []
    shot_plan = [
        ("home-light-390", "#/home", "light", 390, 844),
        ("login-light-390", "#/login", "light", 390, 844),
        ("verify-light-390", "#/verify", "light", 390, 844),
        ("profile-light-390", "#/profile", "light", 390, 844),
        ("jobs-light-390", "#/jobs", "light", 390, 844),
        ("home-light-768", "#/home", "light", 768, 1024),
        ("home-light-1280", "#/home", "light", 1280, 800),
    ]
    # screenshots (light default). Dark: we need to set localStorage — not easy via URL.
    # We'll document dark screenshot as optional; try a query won't work.
    for name, hash_, theme, w, h in shot_plan:
        url = BASE + hash_
        dest = QA / f"{name}.png"
        ok = screenshot(url, dest, w, h)
        shots.append({"name": name, "ok": ok, "size": dest.stat().st_size if dest.exists() else 0})
        print("SHOT", name, "ok" if ok else "FAIL", shots[-1]["size"])

    # file:// smoke for relative HTML
    file_url = ROOT.joinpath("tebyar-prototype.html").as_uri() + "#/home"
    r = chrome(["--dump-dom", "--allow-file-access-from-files", file_url], timeout=40)
    file_dom = r.stdout.decode("utf-8", "replace")
    file_ok = 'data-route="home"' in file_dom and "دکتر سارا کریمی" in file_dom
    print("FILE", "OK" if file_ok else "FAIL", "rc", r.returncode, "len", len(file_dom))

    # standalone file://
    st = ROOT.joinpath("tebyar-prototype.standalone.html").as_uri() + "#/home"
    r2 = chrome(["--dump-dom", "--allow-file-access-from-files", st], timeout=40)
    st_dom = r2.stdout.decode("utf-8", "replace")
    st_ok = 'data-route="home"' in st_dom and "دکتر سارا کریمی" in st_dom
    print("STANDALONE", "OK" if st_ok else "FAIL", "rc", r2.returncode, "len", len(st_dom))

    report = {
        "routes": results,
        "shots": shots,
        "file_protocol_home": file_ok,
        "standalone_file_home": st_ok,
        "failed_routes": [x["route"] for x in results if not x["ok"]],
    }
    (QA / "RESULTS.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = ["# نتایج آزمون محلی headless", "",
             f"مسیرهای موفق: {sum(1 for x in results if x['ok'])}/{len(results)}",
             f"ناموفق: {report['failed_routes'] or '—'}",
             f"file:// نسخهٔ نسبی خانه: {'موفق' if file_ok else 'ناموفق'}",
             f"file:// نسخهٔ خودکفا خانه: {'موفق' if st_ok else 'ناموفق'}",
             "", "## جزئیات"]
    for x in results:
        lines.append(f"- `{x['route']}`: {'OK' if x['ok'] else 'FAIL'} active={x['active']} rtl={x['rtl']} missing={x['missing_text']}")
    (QA / "RESULTS.md").write_text("\n".join(lines)+"\n", encoding="utf-8")
    httpd.shutdown()
    print("wrote", QA / "RESULTS.md")

if __name__ == "__main__":
    main()
