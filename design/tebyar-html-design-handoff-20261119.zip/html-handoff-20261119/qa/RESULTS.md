# نتایج آزمون محلی headless Chrome

این نتایج از رندر واقعی DOM و اسکرین‌شات به‌دست آمده‌اند؛ ساختگی نیستند.

ابزار: Google Chrome headless=new (نسخهٔ نصب‌شده روی جعبه)، بدون Playwright، بدون تعامل مرورگر راه دور.
سرور محلی: `python3 -m http.server 8765` روی همین پوشه. پرچم‌ها: `--no-sandbox --disable-gpu --hide-scrollbars --window-size=…`. پرچم `--virtual-time-budget` و `--user-data-dir` در دورهای اول باعث وقفه می‌شد و در آزمون نهایی استفاده نشد.

تاریخ آزمون: ۱۹ نوامبر ۲۰۲۶، منطقهٔ زمانی Asia/Tehran.

## مسیرها (hash router)

موفق: **۲۲/۲۲** (۱۹ صفحهٔ الزامی + `#/index` + `#/otp` + `#/profile-other`)

برای هر مسیر، dump-dom تأیید کرد که `section.screen.is-active` همان `data-route` است و ویژگی `hidden` نوار پایین با `data-tabbar` صفحه یکی است.

- `index`: OK active=`index` tabbar_hidden=true
- `login`: OK active=`login` tabbar_hidden=true
- `otp`: OK active=`otp` tabbar_hidden=true
- `verify`: OK active=`verify` tabbar_hidden=true
- `home`: OK active=`home` tabbar_hidden=false
- `compose`: OK active=`compose` tabbar_hidden=false
- `post`: OK active=`post` tabbar_hidden=true
- `communities`: OK active=`communities` tabbar_hidden=false
- `community`: OK active=`community` tabbar_hidden=true
- `compose-case`: OK active=`compose-case` tabbar_hidden=false
- `compose-poll`: OK active=`compose-poll` tabbar_hidden=false
- `messages`: OK active=`messages` tabbar_hidden=false
- `chat`: OK active=`chat` tabbar_hidden=true
- `profile`: OK active=`profile` tabbar_hidden=false
- `profile-edit`: OK active=`profile-edit` tabbar_hidden=true
- `profile-other`: OK active=`profile-other` tabbar_hidden=true
- `search`: OK active=`search` tabbar_hidden=true
- `jobs`: OK active=`jobs` tabbar_hidden=true
- `job`: OK active=`job` tabbar_hidden=true
- `apply`: OK active=`apply` tabbar_hidden=true
- `notifications`: OK active=`notifications` tabbar_hidden=true
- `settings`: OK active=`settings` tabbar_hidden=true


## file://

- `tebyar-prototype.html#/home` (به‌همراه css/js/assets نسبی): dump-dom مسیر خانه را فعال نشان داد؛ اسکرین‌شات ۳۹۰×۸۴۴ با هدر RTL و نوار پایین رندر شد.
- `tebyar-prototype.standalone.html#/home` (بدون ارجاع نسبی به css/js/assets): dump-dom مسیر خانه را فعال نشان داد و ارجاع `assets/` یا `css/tebyar.css` باقی نماند؛ اسکرین‌شات ۳۹۰×۸۴۴ با هدر RTL و نوار پایین رندر شد (`qa/file-standalone-home-390.png`, `qa/file-folder-home-390.png`).

در منابع HTML/CSS/JS آدرس خارجی `http(s)://` برای فونت یا ظاهر اصلی وجود ندارد.

## اسکرین‌شات‌های گرفته‌شده (پس از اصلاح موقعیت نوار پایین)

- `apply-light-390.png`: OK (69657 bytes)
- `chat-light-390.png`: OK (58938 bytes)
- `communities-light-390.png`: OK (98717 bytes)
- `compose-light-390.png`: OK (196033 bytes)
- `file-folder-home-390.png`: OK (276447 bytes)
- `file-standalone-home-390.png`: OK (276486 bytes)
- `home-dark-390.png`: OK (276053 bytes)
- `home-light-1280.png`: OK (472590 bytes)
- `home-light-390.png`: OK (276496 bytes)
- `home-light-768.png`: OK (404219 bytes)
- `jobs-light-390.png`: OK (62749 bytes)
- `login-light-390.png`: OK (69803 bytes)
- `messages-light-390.png`: OK (67894 bytes)
- `notifications-light-390.png`: OK (48528 bytes)
- `otp-light-390.png`: OK (51848 bytes)
- `post-light-390.png`: OK (206264 bytes)
- `profile-light-390.png`: OK (97247 bytes)
- `search-light-390.png`: OK (72841 bytes)
- `settings-light-390.png`: OK (66448 bytes)
- `verify-light-390.png`: OK (86687 bytes)

## مشاهده‌های بصری تأییدشده از اسکرین‌شات (نه حدس)

- خانه روشن/تیره ۳۹۰×۸۴۴: درخشش بنفش/مرجانی هدر، جستجو و زنگ در چپ، نشان‌واره (مونوگرام سپس «طبیار») در راست، استوری مستطیلی با «استوری شما» در راست‌ترین، توضیح پست زیر عکس، واکنش‌ها با قلب در راست‌ترین، نوار پایین شناور با ترتیب RTL: خانه (راست) / انجمن / انتشار / پیام‌ها / پروفایل (چپ).
- ورود: نوار پایین مخفی است؛ فیلد شمارهٔ نمونه‌ای و هشدار عدم ورود اطلاعات واقعی دیده می‌شود.
- پروفایل و انجمن‌ها: دکمه/آیکن در اندازهٔ عادی؛ زبانهٔ فعال نوار پایین درست است.
- خانه در ۱۲۸۰×۸۰۰: ستون مرکزی حدود حداکثر پهنا، نوار پایین داخل همان ستون.

## محدودیت آزمون

- این آزمون تقابل پیکسل‌به‌پیکسل با PNG مرجع خانه نیست؛ شباهت بصری با چشم روی اسکرین‌شات‌های بالا بررسی شد.
- همهٔ ۱۹ صفحه در dump-dom پوشش داده شدند؛ همه در اسکرین‌شات جداگانه نیستند (پوشش تصویری روی جریان‌های اصلی و چند صفحهٔ فاز ۲ است).
- حالت‌های نوار نمونه (اسکلت/خالی/خطا/بارگذاری) با dump-dom مسیرها جداگانه اسکرین نشدند.
- فوکوس صفحه‌کلید و حرکت لمسی واقعی آزمون نشد؛ فقط CSS/نشانگرهای اندازه در کد اعمال شده است.
- Playwright نصب نبود.
