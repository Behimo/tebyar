/* طبیار — prototype interactions only. No network, no real auth, no persistence except theme. */
(function () {
  "use strict";

  const THEME_KEY = "tebyar-theme";
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

  const ROUTES = [
    "index","login","otp","verify","home","compose","post","communities","community",
    "compose-case","compose-poll","messages","chat","profile","profile-edit","profile-other",
    "search","jobs","job","apply","notifications","settings"
  ];

  function currentTheme() {
    return document.documentElement.getAttribute("data-theme") || "light";
  }
  function setTheme(theme) {
    const t = theme === "dark" ? "dark" : "light";
    document.documentElement.setAttribute("data-theme", t);
    try { localStorage.setItem(THEME_KEY, t); } catch (e) { /* ignore */ }
    const sel = $("#themeSelect");
    if (sel) sel.value = t;
    $$(".theme-label").forEach((el) => { el.textContent = t === "dark" ? "تیره" : "روشن"; });
  }
  function initTheme() {
    let t = "light";
    try { t = localStorage.getItem(THEME_KEY) || "light"; } catch (e) { t = "light"; }
    try {
      const q = new URLSearchParams(location.search).get("theme");
      if (q === "dark" || q === "light") t = q;
    } catch (e) {}
    setTheme(t);
  }

  function parseHash() {
    const raw = (location.hash || "#/home").replace(/^#\/?/, "").trim();
    const name = raw.split("/")[0] || "home";
    return ROUTES.includes(name) ? name : "home";
  }

  function navigate(name, opts) {
    const route = ROUTES.includes(name) ? name : "home";
    if (!opts || !opts.replace) {
      if (location.hash !== "#/" + route) location.hash = "#/" + route;
    }
    applyRoute(route);
  }

  function applyRoute(name) {
    $$(".screen").forEach((s) => s.classList.toggle("is-active", s.dataset.route === name));
    const screen = $(`.screen[data-route="${name}"]`);
    const tabbar = $("#tabbar");
    if (tabbar) {
      const off = !screen || screen.getAttribute("data-tabbar") === "off";
      tabbar.hidden = off;
      tabbar.setAttribute("aria-hidden", off ? "true" : "false");
    }
    const nav = screen && screen.dataset.nav;
    $$("#tabbar .tab").forEach((t) => {
      const on = nav && t.dataset.nav === nav;
      t.classList.toggle("is-active", on);
      if (on) t.setAttribute("aria-current", "page");
      else t.removeAttribute("aria-current");
    });
    const sel = $("#routeSelect");
    if (sel && sel.value !== name) sel.value = name;
    const heading = screen && (screen.querySelector("h1, .page-title, .brand"));
    if (screen) screen.focus({ preventScroll: true });
    closeOverlays(false);
    applyVerifyStatus();
    applyDemoState();
    const main = $("#main");
    if (main) main.scrollTop = 0;
    if (screen) {
      const body = screen.querySelector(".screen-body");
      if (body) body.scrollTop = 0;
    }
    document.title = "طبیار — نمونه طراحی" + (screen && screen.dataset.title ? " — " + screen.dataset.title : "");
  }

  function toast(msg) {
    const el = $("#toast");
    if (!el) return;
    el.textContent = msg;
    el.classList.add("is-on");
    clearTimeout(toast._t);
    toast._t = setTimeout(() => el.classList.remove("is-on"), 2600);
  }

  function closeOverlays(alsoStory) {
    $$(".overlay").forEach((o) => o.classList.remove("is-open"));
    if (alsoStory !== false) {
      const sv = $("#storyViewer");
      if (sv) sv.classList.remove("is-open");
    }
  }

  function applyDemoState() {
    const state = document.body.getAttribute("data-demo-state") || "ideal";
    // Form loading / disabled examples
    $$("[data-demo-submit]").forEach((btn) => {
      btn.classList.toggle("is-loading", state === "loading");
      btn.disabled = state === "loading" || state === "empty";
      if (state === "loading") btn.setAttribute("aria-busy", "true");
      else btn.removeAttribute("aria-busy");
    });
    $$("[data-demo-field]").forEach((f) => {
      f.classList.toggle("is-error", state === "error");
      const input = f.querySelector("input, textarea, select");
      if (input) input.disabled = state === "loading";
    });
  }

  function applyVerifyStatus() {
    const st = document.body.getAttribute("data-verify-status") || "pending";
    $$("[data-vstatus]").forEach((el) => {
      el.hidden = el.getAttribute("data-vstatus") !== st;
    });
    const label = $("#verifyStatusLabel");
    const map = {
      pending: "در انتظار بررسی",
      verified: "تأییدشده",
      correction: "نیاز به اصلاح",
      suspended: "معلق",
      revoked: "لغوشده"
    };
    if (label) label.textContent = map[st] || st;
  }

  function openStory(key) {
    const data = {
      sara: { name: "سارا", src: "assets/images/story-sara-coffee.jpg" },
      mohammad: { name: "محمد", src: "assets/images/story-mohammad.jpg" },
      niloufar: { name: "نیلوفر", src: "assets/images/story-niloufar.jpg" },
      kasra: { name: "کسری", src: "assets/images/story-kasra.jpg" }
    };
    const item = data[key] || data.sara;
    const sv = $("#storyViewer");
    if (!sv) return;
    sv.querySelector(".story-name").textContent = item.name;
    sv.querySelector(".media img").src = item.src;
    sv.querySelector(".media img").alt = "استوری نمایشی " + item.name;
    sv.classList.add("is-open");
    const bars = $$(".story-viewer .progress span");
    bars.forEach((b) => b.classList.remove("active"));
    if (bars[0]) {
      const inner = bars[0].querySelector("i");
      if (inner) inner.style.width = "";
      bars[0].classList.add("active");
    }
  }

  document.addEventListener("click", (e) => {
    const go = e.target.closest("[data-go]");
    if (go) {
      e.preventDefault();
      navigate(go.getAttribute("data-go"));
      return;
    }
    const story = e.target.closest("[data-story]");
    if (story) {
      e.preventDefault();
      openStory(story.getAttribute("data-story"));
      return;
    }
    if (e.target.closest("[data-close-story]")) {
      closeOverlays(true);
      return;
    }
    if (e.target.closest("[data-open-compose]")) {
      e.preventDefault();
      const ov = $("#composeSheet");
      if (ov) ov.classList.add("is-open");
      return;
    }
    if (e.target.closest("[data-close-sheet]")) {
      const ov = e.target.closest(".overlay");
      if (ov) ov.classList.remove("is-open");
      return;
    }
    const ov = e.target.classList.contains("overlay") ? e.target : null;
    if (ov) ov.classList.remove("is-open");

    const like = e.target.closest("[data-like]");
    if (like) {
      like.classList.toggle("is-on");
      like.setAttribute("aria-pressed", like.classList.contains("is-on") ? "true" : "false");
      return;
    }
    const bm = e.target.closest("[data-bookmark]");
    if (bm) {
      const on = bm.classList.toggle("is-on");
      bm.setAttribute("aria-pressed", on ? "true" : "false");
      toast(on ? "برای بعد ذخیره شد (فقط در این پیش‌نمایش)." : "از ذخیره خارج شد.");
      return;
    }
    const tog = e.target.closest("[data-toggle]");
    if (tog) {
      tog.classList.toggle("on");
      tog.setAttribute("aria-checked", tog.classList.contains("on") ? "true" : "false");
      return;
    }
    if (e.target.closest("[data-fake-submit]")) {
      e.preventDefault();
      const state = document.body.getAttribute("data-demo-state");
      if (state === "error") {
        toast("خطای نمایشی: ارسال انجام نشد. این فرم به سرور وصل نیست.");
        return;
      }
      toast("ارسال واقعی انجام نمی‌شود. این فقط پیش‌نمایش طراحی است.");
      return;
    }
    if (e.target.closest("[data-fake-otp]")) {
      e.preventDefault();
      const inputs = $$(".otp-row input");
      const val = inputs.map((i) => i.value).join("");
      if (val === "2483" || val === "۲۴۸۳") {
        toast("کد نمایشی پذیرفته شد. احراز هویت مرحله بعد است.");
        navigate("verify");
      } else {
        toast("کد نمایشی این نمونه ۲۴۸۳ است. پیامکی ارسال نمی‌شود.");
        $(".otp-row").classList.add("is-error");
      }
      return;
    }
    if (e.target.closest("[data-fill-otp]")) {
      e.preventDefault();
      const digits = ["2", "4", "8", "3"];
      $$(".otp-row input").forEach((inp, i) => { inp.value = digits[i] || ""; });
      return;
    }
  });

  document.addEventListener("submit", (e) => {
    e.preventDefault();
    toast("ارسال واقعی انجام نمی‌شود. این فقط پیش‌نمایش طراحی است.");
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeOverlays(true);
  });

  $$(".otp-row input").forEach((inp, i, arr) => {
    inp.addEventListener("input", () => {
      inp.value = inp.value.replace(/[^0-9۰-۹]/g, "").slice(0, 1);
      if (inp.value && arr[i + 1]) arr[i + 1].focus();
    });
    inp.addEventListener("keydown", (ev) => {
      if (ev.key === "Backspace" && !inp.value && arr[i - 1]) arr[i - 1].focus();
    });
  });

  const themeSelect = $("#themeSelect");
  if (themeSelect) themeSelect.addEventListener("change", () => setTheme(themeSelect.value));
  const themeBtn = $("#themeToggleBtn");
  if (themeBtn) themeBtn.addEventListener("click", () => setTheme(currentTheme() === "dark" ? "light" : "dark"));

  const routeSelect = $("#routeSelect");
  if (routeSelect) routeSelect.addEventListener("change", () => navigate(routeSelect.value));

  const stateSelect = $("#stateSelect");
  if (stateSelect) {
    stateSelect.addEventListener("change", () => {
      document.body.setAttribute("data-demo-state", stateSelect.value);
      applyDemoState();
    });
  }
  const verifySelect = $("#verifySelect");
  if (verifySelect) {
    verifySelect.addEventListener("change", () => {
      document.body.setAttribute("data-verify-status", verifySelect.value);
      applyVerifyStatus();
    });
  }

  window.addEventListener("hashchange", () => applyRoute(parseHash()));

  initTheme();
  document.body.setAttribute("data-demo-state", "ideal");
  document.body.setAttribute("data-verify-status", "pending");
  if (!location.hash) location.hash = "#/home";
  applyRoute(parseHash());
})();
